# Android/Termux Port Report — v5.1

## Base

This port uses the newest upstream source contained in the provided
`google-colab-cli-latest.zip` as the base. The previous Android v3 tree was used
only as a compatibility reference; older core command files were not copied over
the newer upstream implementation.

The provided upstream tree contains the v0.7.2 release plus a newer upstream
commit that adds compatibility for newer `jupyter-kernel-client` package names.
The Android port keeps the rest of that newer upstream command surface.

## Design rule

The port avoids one-off fixes when a shared compatibility layer can solve the
same dependency problem for multiple commands. Changes are kept at dependency
boundaries so that future upstream command changes are less likely to conflict
with Android-specific code.

## Compatibility changes

### Notebook handling

Upstream dependency path:

`nbformat -> jsonschema -> referencing -> rpds-py`

`rpds-py` is a Rust extension and is a common Termux installation failure point.
The CLI only needs a small nbformat-v4 surface, so this port routes both notebook
execution and history export/conversion through `colab_cli.ipynb_lite`.

Affected upstream consumers:

- `src/colab_cli/commands/execution.py`
- `src/colab_cli/converter.py`

This single adapter covers reading, writing, cell creation, output creation, cell
IDs, and recursive NotebookNode-style attribute access.

### Data models

Upstream `pydantic` pulls `pydantic-core`, a Rust extension. All current model
consumers use a limited surface: typed fields, aliases, defaults, enums,
containers, unions, `model_validate`, `model_dump`, `model_dump_json`,
`model_copy`, and `TypeAdapter`.

Those operations are provided by `colab_cli.pydantic_lite` and shared by:

- `src/colab_cli/client.py`
- `src/colab_cli/state.py`
- `src/colab_cli/consumption.py`

The newer `colab usage` response models are therefore covered by the same model
adapter instead of adding a separate workaround.

### Kernel transport

The external `jupyter-kernel-client` dependency is replaced by
`colab_cli.ws_kernel`, a focused JSON WebSocket implementation of the Jupyter v5
operations used by Colab CLI.

`src/colab_cli/runtime.py` remains based on the newest upstream runtime flow. Only
transport-specific integration points were changed. The port preserves:

- kernel creation and reconnection by kernel/session ID
- streaming output
- `clear_output(wait=True)` buffering semantics
- stdin requests
- inactivity timeouts
- kernel restart and shutdown
- Colab-specific request interception used by Drive mounting

The old Android `runtime.py` was deliberately not copied over the new upstream
file because doing so would discard newer upstream fixes.

### Authentication dependency

`google-auth` is pinned to `>=2.47,<2.48`. This retains the credential,
AuthorizedSession, ADC, refresh, and OAuth APIs used by the CLI while avoiding the
newer mandatory native `cryptography` dependency chain that is problematic on
Termux.

This is a dependency-boundary pin, not a replacement authentication
implementation.

### Update safety

The upstream self-updater would replace this Android build with the official PyPI
package and restore the native dependency chains. On Android/Termux:

- `colab update` may still report a newer upstream release.
- `colab update --install` is disabled.
- the message explicitly tells the user to install a newer Android-compatible
  source build instead.

The upstream `uv.lock` is omitted because it no longer represents this port's
dependency graph. The supported installation path is pip from the source tree.

### SSH runtime environment

An audit of the upstream SSH path found a separate runtime-environment bug that
is not Android-specific: GPU device nodes may be mounted in the VM while the SSH
login shell lacks the NVIDIA driver-library directory in `LD_LIBRARY_PATH`. This
causes tools such as `nvidia-smi` and CUDA consumers to fail even though the T4
was allocated correctly.

The fix is applied once at the interactive SSH boundary rather than in individual
GPU tools. It conditionally probes known Colab/NVIDIA driver directories, only
adds a directory when it contains NVML or libcuda, preserves existing loader
paths, and avoids duplicate entries. CPU/TPU runtimes therefore keep their old
behavior.

Sibling-path audit:

- direct `colab ssh`: fixed by the shared remote-shell bootstrap
- auto-created vs reused SSH sessions: both use the same bootstrap
- `colab ssh --proxy-mode`: transport-only by design; external SSH clients own
  their remote command and must opt into the documented equivalent bootstrap
- `colab exec`, `colab run`, `colab console`: kernel-backed and already inherit
  the notebook runtime environment, so no duplicate fix was added
- `scp`/`sftp`: transport/file-transfer paths do not require an interactive GPU
  shell environment

Regression coverage lives with the existing SSH workdir tests so the `/content`,
identity forwarding, and login-shell behavior remain pinned alongside the new
loader-path bootstrap.

### Integration runner portability

The prior T4 SSH regression exposed a second cross-platform issue: individual
integration scripts hardcoded `uv run`, while the repository's `.python-version`
selects Python 3.12. On Termux, the installed Python can be a newer supported
version while uv has no managed Android CPython 3.12 build, so the test failed
before calling Colab and then incorrectly reported that T4 allocation was
unavailable.

The fix is shared instead of GPU-test-specific. Shell integration scenarios now
route CLI/Python execution through `integration/_runner.sh`:

- normal upstream development keeps `uv run colab`
- Android/Termux executes the current `src/` tree with the active Python
- explicit installed-package testing remains available as an override
- generated OpenSSH `ProxyCommand` strings use the same runner selection
- runner/import/config failures remain failures instead of being converted to
  backend-resource skips

This avoids changing `.python-version` (which would affect upstream development)
and avoids testing a stale global `colab` merely to work around uv on Android.

## Diagnostic command

`colab test` runs safe local diagnostics without allocating or modifying a Colab
runtime.

Available checks:

```text
colab test
colab test environment
colab test notebook
colab test models
colab test kernel-codec
colab test kernel -s <session>
```

The live kernel check is opt-in and executes only:

```python
print("COLAB_ANDROID_TEST_OK")
```

## Validation performed before packaging

The build was checked for:

- Python source compilation
- no direct runtime imports of `nbformat`, `pydantic`, `jupyter_kernel_client`,
  or `cryptography`
- notebook v4 JSON round-trip
- aliases, numeric coercion, unknown-field tolerance, and dump behavior used by
  `colab usage`
- Jupyter stream-message conversion
- runtime transport wiring
- kernel-client construction parameters
- error-output normalization
- streaming-output buffering and timeout forwarding
- CLI registration of both existing upstream commands and `colab test`
- Android/Termux self-update guard
- shared integration-runner policy in `uv`, Termux/source, and explicit installed modes
- shell syntax for every integration scenario after runner migration
- no per-scenario hardcoded `uv run colab` / `uv run python` remains
- T4 regression distinguishes local runner failures from resource/quota skips

The build environment used for packaging has no external network access and does
not contain the complete project dependency set, so a full network-backed Colab
integration test could not be run there. The included live diagnostic exists for
that final device/runtime verification.

## Recommended device test order

```bash
pip install . --break-system-packages
colab version
colab test
colab --help
colab new -s android-test
colab test kernel -s android-test
echo 'print("hello from Termux")' | colab exec -s android-test
colab usage
colab sessions
colab status -s android-test
colab stop -s android-test
```

Then test higher-level features individually: upload/download, notebook execution,
Drive mounting, REPL/console, SSH, `run`, and automation commands.
