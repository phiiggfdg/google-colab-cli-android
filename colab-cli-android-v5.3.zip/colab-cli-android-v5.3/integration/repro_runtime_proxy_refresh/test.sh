#!/bin/bash
# Integration Test: runtime-proxy credential renewal/recovery.
#
# Forces stale proxy credentials without waiting ~60 minutes and verifies:
#   1. pre-command refresh heals an expired token before Contents API access;
#   2. a 401/404 with a still-live assignment refreshes credentials instead of
#      deleting local state, so the next command succeeds;
#   3. cleanup still removes the assignment.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../_runner.sh"

if [ -f "$HOME/.config/colab-cli/token.json" ]; then
    AUTH_FLAGS="--auth=oauth2"
elif command -v gcloud > /dev/null && gcloud auth application-default print-access-token > /dev/null 2>&1; then
    AUTH_FLAGS="--auth=adc"
else
    echo "Error: No usable auth provider found."
    exit 1
fi

TMP_DIR=$(mktemp -d)
SESSION_FILE="$TMP_DIR/sessions.json"
SESSION="repro-proxy-refresh-$(date +%s)"

cleanup() {
    echo "[*] Cleaning up..."
    run_colab $AUTH_FLAGS --config "$SESSION_FILE" stop -s "$SESSION" 2>/dev/null || true
    rm -rf "$TMP_DIR"
}
trap cleanup EXIT

set_token_state() {
    TOKEN="$1" EXPIRES="$2" run_project_python - "$SESSION_FILE" "$SESSION" <<'PY'
import os, sys
from colab_cli.state import StateStore
store = StateStore(sys.argv[1])
expires = float(os.environ["EXPIRES"])
updated = store.update(sys.argv[2], token=os.environ["TOKEN"], token_expires_at=expires)
assert updated is not None
PY
}

echo "[*] Creating session '$SESSION'..."
run_colab $AUTH_FLAGS --config "$SESSION_FILE" new -s "$SESSION" || exit 1

# Phase 1: legacy/expired credential is refreshed before a file command.
echo "[*] Phase 1: force expired token, then run colab ls"
set_token_state "definitely-invalid-runtime-proxy-token" 0
OUT=$(run_colab $AUTH_FLAGS --config "$SESSION_FILE" ls -s "$SESSION" content 2>&1)
RC=$?
echo "$OUT"
if [ $RC -ne 0 ]; then
    echo "[FAILURE] pre-command credential refresh did not heal Contents API access."
    exit 1
fi
echo "[SUCCESS] Phase 1 passed: expired token refreshed before file access."

# Phase 2: make the token invalid while claiming it is fresh so resolve_session
# will not proactively renew it. The first runtime request should hit 401/404;
# the terminal-error guard must confirm the assignment and refresh instead of
# pruning it. A second command must then succeed.
echo "[*] Phase 2: force reactive 401/404 recovery without pruning"
FAR_FUTURE=4102444800
set_token_state "definitely-invalid-runtime-proxy-token" "$FAR_FUTURE"
OUT=$(printf 'print("first attempt")\n' | run_colab $AUTH_FLAGS --config "$SESSION_FILE" exec -s "$SESSION" 2>&1)
RC=$?
echo "$OUT"
if [ $RC -eq 0 ]; then
    echo "[FAILURE] invalid token unexpectedly succeeded; reactive path was not exercised."
    exit 1
fi
if ! echo "$OUT" | grep -q "assignment is still alive"; then
    echo "[FAILURE] terminal proxy error was not reconciled against the live assignment."
    exit 1
fi

OUT=$(printf 'print("RECOVERED_OK")\n' | run_colab $AUTH_FLAGS --config "$SESSION_FILE" exec -s "$SESSION" 2>&1)
RC=$?
echo "$OUT"
if [ $RC -ne 0 ] || ! echo "$OUT" | grep -q "RECOVERED_OK"; then
    echo "[FAILURE] command did not recover after credentials were refreshed."
    exit 1
fi

echo "[SUCCESS] Phase 2 passed: live assignment preserved and next command recovered."
echo "[SUCCESS] Runtime-proxy refresh/recovery regression passed."
