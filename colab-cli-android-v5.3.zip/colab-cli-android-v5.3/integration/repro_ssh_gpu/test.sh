#!/bin/bash
# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Live regression for SSH GPU userspace libraries (issue #148 class).
# Opt-in because it allocates a T4 and can consume accelerator quota:
#   RUN_GPU_SSH_E2E=1 bash integration/repro_ssh_gpu/test.sh

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/../_runner.sh"

if [ "${RUN_GPU_SSH_E2E:-0}" != "1" ]; then
  echo "[skip] Set RUN_GPU_SSH_E2E=1 to allocate a T4 and run this regression."
  exit 0
fi

if [ -f "$HOME/.config/colab-cli/token.json" ]; then
  AUTH_FLAGS="--auth=oauth2"
elif command -v gcloud >/dev/null && \
     gcloud auth application-default print-access-token >/dev/null 2>&1; then
  AUTH_FLAGS="--auth=adc"
else
  echo "[skip] no usable Colab auth provider"
  exit 0
fi

for tool in ssh ssh-keygen timeout; do
  if ! command -v "$tool" >/dev/null; then
    echo "[skip] required tool '$tool' not found"
    exit 0
  fi
done

TMP_DIR=$(mktemp -d)
SESSION_FILE="$TMP_DIR/sessions.json"
KEY="$TMP_DIR/id_ed25519"
SESSION_NAME="repro-ssh-gpu-$(date +%s)"
SESSION_CREATED=0

cleanup() {
  if [ "$SESSION_CREATED" = "1" ]; then
    run_colab $AUTH_FLAGS --config "$SESSION_FILE" stop -s "$SESSION_NAME" \
      >/dev/null 2>&1 || true
  fi
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

ssh-keygen -t ed25519 -N "" -f "$KEY" >/dev/null
integration_runner_info

echo "[*] Creating T4 runtime '$SESSION_NAME'..."
CREATE_OUT=$(run_colab $AUTH_FLAGS --config "$SESSION_FILE" new \
  -s "$SESSION_NAME" --gpu T4 2>&1)
CREATE_RC=$?
printf '%s\n' "$CREATE_OUT"
if [ "$CREATE_RC" -ne 0 ]; then
  if printf '%s' "$CREATE_OUT" | grep -qiE \
      'quota|resource.?exhausted|accelerator.*(unavailable|not available)|T4.*(unavailable|not available)|no.*T4|not entitled'; then
    echo "[skip] T4 allocation unavailable for this account/session"
    exit 0
  fi
  echo "[FAILURE] colab new failed before T4 availability could be verified (exit $CREATE_RC)."
  exit "$CREATE_RC"
fi
SESSION_CREATED=1

REMOTE_ENV=$(run_project_python - <<'PY'
from colab_cli.commands.ssh import _build_remote_env_prelude
print(_build_remote_env_prelude())
PY
)
if [ -z "$REMOTE_ENV" ]; then
  echo "[FAILURE] SSH environment bootstrap unexpectedly rendered empty."
  exit 1
fi

PROXY=$(colab_command $AUTH_FLAGS --config "$SESSION_FILE" ssh --proxy-mode \
  -s "$SESSION_NAME" -i "$KEY")
REMOTE_CHECK="${REMOTE_ENV} nvidia-smi -L; python -c 'import ctypes; ctypes.CDLL(\"libnvidia-ml.so.1\"); ctypes.CDLL(\"libcuda.so.1\"); print(\"GPU_LIBS_OK\")'"

OUT=$(timeout 120 ssh -F /dev/null \
  -o "ProxyCommand=$PROXY" \
  -o StrictHostKeyChecking=no \
  -o UserKnownHostsFile=/dev/null \
  -o BatchMode=yes \
  -o ConnectTimeout=60 \
  -o LogLevel=ERROR \
  -i "$KEY" \
  root@colab-runtime "$REMOTE_CHECK" 2>&1)
RC=$?
echo "$OUT"

if [ "$RC" -ne 0 ]; then
  echo "[FAILURE] SSH GPU environment regression failed (exit $RC)."
  exit 1
fi
if ! echo "$OUT" | grep -q "GPU_LIBS_OK"; then
  echo "[FAILURE] NVIDIA userspace libraries were not loadable over SSH."
  exit 1
fi
if ! echo "$OUT" | grep -qiE "GPU [0-9]+:|Tesla T4|T4"; then
  echo "[FAILURE] nvidia-smi did not report an allocated GPU."
  exit 1
fi

echo "[SUCCESS] T4 device + NVML + libcuda are usable through the SSH environment bootstrap."
