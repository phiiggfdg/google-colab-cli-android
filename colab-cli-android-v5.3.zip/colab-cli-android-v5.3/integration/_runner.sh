#!/bin/bash
# Shared integration-test command runner.
#
# Upstream development normally runs through `uv`, which guarantees the local
# checkout is used. Android/Termux has a valid system Python (often newer than
# `.python-version`) but `uv run` may insist on downloading the pinned CPython
# build, which is not available for Android. In that environment we execute the
# current source tree directly with the active Python instead of falling back to
# a potentially stale globally-installed `colab` command.
#
# Override when needed:
#   COLAB_TEST_RUNNER=uv         # force `uv run colab`
#   COLAB_TEST_RUNNER=source     # force `python -m colab_cli.cli`
#   COLAB_TEST_RUNNER=installed  # force installed `colab`
#   PYTHON_BIN=/path/to/python
#   COLAB_BIN=/path/to/colab

_INTEGRATION_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COLAB_REPO_ROOT="$(cd "${_INTEGRATION_DIR}/.." && pwd)"

_colab_is_termux() {
  [ -n "${TERMUX_VERSION:-}" ] || [ -n "${TERMUX_APP_PID:-}" ] || \
    case "${PREFIX:-}" in
      */com.termux/*) return 0 ;;
      *) return 1 ;;
    esac
}

_colab_runner_mode() {
  local requested="${COLAB_TEST_RUNNER:-auto}"
  case "$requested" in
    uv|source|installed) printf '%s\n' "$requested"; return 0 ;;
    auto) ;;
    *)
      echo "[runner] invalid COLAB_TEST_RUNNER='$requested' (use auto|uv|source|installed)" >&2
      return 2
      ;;
  esac

  if _colab_is_termux; then
    printf '%s\n' source
  elif command -v uv >/dev/null 2>&1; then
    printf '%s\n' uv
  elif command -v "${COLAB_BIN:-colab}" >/dev/null 2>&1; then
    printf '%s\n' installed
  else
    printf '%s\n' source
  fi
}

_colab_python_bin() {
  if [ -n "${PYTHON_BIN:-}" ]; then
    printf '%s\n' "$PYTHON_BIN"
  elif command -v python >/dev/null 2>&1; then
    command -v python
  elif command -v python3 >/dev/null 2>&1; then
    command -v python3
  else
    echo "[runner] Python was not found; set PYTHON_BIN=/path/to/python" >&2
    return 127
  fi
}

_colab_source_pythonpath() {
  if [ -n "${PYTHONPATH:-}" ]; then
    printf '%s:%s\n' "$COLAB_REPO_ROOT/src" "$PYTHONPATH"
  else
    printf '%s\n' "$COLAB_REPO_ROOT/src"
  fi
}

run_colab() {
  local mode
  mode="$(_colab_runner_mode)" || return $?
  case "$mode" in
    uv)
      (cd "$COLAB_REPO_ROOT" && uv run colab "$@")
      ;;
    source)
      local py
      py="$(_colab_python_bin)" || return $?
      PYTHONPATH="$(_colab_source_pythonpath)" "$py" -m colab_cli.cli "$@"
      ;;
    installed)
      "${COLAB_BIN:-colab}" "$@"
      ;;
  esac
}

run_project_python() {
  local mode
  mode="$(_colab_runner_mode)" || return $?
  if [ "$mode" = uv ]; then
    (cd "$COLAB_REPO_ROOT" && uv run python "$@")
  else
    local py
    py="$(_colab_python_bin)" || return $?
    PYTHONPATH="$(_colab_source_pythonpath)" "$py" "$@"
  fi
}

# Print a shell-escaped command suitable for OpenSSH ProxyCommand or bash -c.
colab_command() {
  local mode py
  mode="$(_colab_runner_mode)" || return $?
  local -a cmd
  case "$mode" in
    uv)
      cmd=(uv run colab)
      ;;
    source)
      py="$(_colab_python_bin)" || return $?
      cmd=(env "PYTHONPATH=$(_colab_source_pythonpath)" "$py" -m colab_cli.cli)
      ;;
    installed)
      cmd=("${COLAB_BIN:-colab}")
      ;;
  esac
  cmd+=("$@")
  printf '%q ' "${cmd[@]}"
  printf '\n'
}

integration_runner_info() {
  local mode
  mode="$(_colab_runner_mode)" || return $?
  echo "[runner] mode=$mode repo=$COLAB_REPO_ROOT"
  if [ "$mode" = source ]; then
    echo "[runner] python=$(_colab_python_bin)"
  fi
}
