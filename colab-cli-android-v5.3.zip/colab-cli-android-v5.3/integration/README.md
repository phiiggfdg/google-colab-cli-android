# Integration tests

End-to-end tests that run against a **live Colab backend** (unlike the mocked unit tests under `tests/`).

## Prerequisites
- Google account with Colab access.
- `uv` installed for the normal upstream development workflow. On Android/Termux, the shared runner uses the active Python and current source tree instead.
- Working auth — verify with `colab sessions`.

## Scenarios

| Directory | What it covers |
| --- | --- |
| `repro_plot_redirection/` | `colab exec` of a matplotlib script with `--output-image` redirection. |
| `repro_keep_alive/` | Fast smoke test (~10s): keep-alive daemon spawns, persists its PID, no errors during the pre-flight ping, `colab stop` reaps it. |
| `repro_keep_alive_scope/` | Slow soak test (~95s): runs the daemon long enough for one ping past the pre-flight, asserts no `keep_alive_error` events. |
| `repro_variable_persistence/` | Variables persist across `colab exec` calls in the same session. |
| `repro_piped_console/` | Fast smoke test (~5s including session creation): `echo cmd \| colab console -s s` runs the command and exits within 30s. Regression test for the 2026-05-07 EOF-handler fix. |
| `repro_bundled_oauth/` | Fast smoke test (~5s): verifies that the fallback OAuth configuration is loaded and starts the OAuth flow with the default client ID when local config is missing. |
| `repro_ssh/` | Fast smoke test (~5s): `--help` advertises the flags and an unknown session exits. Slow soak test (~95s): Live e2e allocates a CPU VM, runs a real remote command over `colab ssh --proxy-mode` |
| `repro_ssh_gpu/` | Opt-in live T4 regression for SSH GPU driver-library discovery (`RUN_GPU_SSH_E2E=1`); verifies `nvidia-smi`, NVML, and libcuda through the same bootstrap used by direct `colab ssh`. |


## Running
```bash
bash integration/repro_keep_alive/test.sh
```

All shell scenarios source `integration/_runner.sh`. In the normal upstream development environment it runs the CLI through `uv`; on Android/Termux it runs the current source tree with the active Python, avoiding `.python-version` download assumptions while still preventing a stale global `colab` from being tested.

Overrides are available for debugging:

```bash
COLAB_TEST_RUNNER=uv bash integration/repro_ssh/test.sh
COLAB_TEST_RUNNER=source bash integration/repro_ssh/test.sh
COLAB_TEST_RUNNER=installed COLAB_BIN="$(command -v colab)" bash integration/repro_ssh/test.sh
```

## Adding a scenario
1. Create `repro_<short_description>/`.
2. Add a script (`.sh` or `.py`) that demonstrates or verifies the issue.
3. Add a row to the table above noting whether it's fast (smoke) or slow (soak).
