import json

from colab_cli.execution_input import load_execution_file


def test_notebook_loader_normalizes_list_source_and_adds_cell_ids(tmp_path):
    path = tmp_path / "list-source.ipynb"
    path.write_text(
        json.dumps(
            {
                "cells": [
                    {
                        "cell_type": "code",
                        "metadata": {},
                        "outputs": [],
                        "source": ["a = 1\n", "print(a)"],
                    }
                ],
                "metadata": {},
                "nbformat": 4,
                "nbformat_minor": 5,
            }
        ),
        encoding="utf-8",
    )

    loaded = load_execution_file(str(path))

    assert loaded.is_notebook
    assert loaded.blocks[0].code == "a = 1\nprint(a)"
    assert loaded.blocks[0].cell_id
    assert loaded.blocks[0].cell.id == loaded.blocks[0].cell_id
