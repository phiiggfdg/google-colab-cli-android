from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from colab_cli.cli import app


runner = CliRunner()


def test_diagnostics_all_local_checks():
    result = runner.invoke(app, ["test"])
    assert result.exit_code == 0, result.output
    assert "[PASS] environment" in result.output
    assert "[PASS] notebook" in result.output
    assert "[PASS] models" in result.output
    assert "[PASS] kernel-codec" in result.output
    assert "Live kernel execution is intentionally not run by default" in result.output


def test_diagnostics_single_check():
    result = runner.invoke(app, ["test", "models"])
    assert result.exit_code == 0, result.output
    assert "[PASS] models" in result.output
    assert "[PASS] notebook" not in result.output


def test_diagnostics_kernel_requires_session():
    result = runner.invoke(app, ["test", "kernel"])
    assert result.exit_code == 1
    assert "pass an existing session" in result.output


def test_diagnostics_live_kernel_success(mock_common_state):
    saved = MagicMock()
    saved.url = "https://runtime.example"
    saved.token = "token"
    saved.kernel_id = "kid"
    saved.session_id = "sid"
    mock_common_state.store.get.return_value = saved

    runtime = MagicMock()
    runtime.execute_code.return_value = [
        {"output_type": "stream", "name": "stdout", "text": "COLAB_ANDROID_TEST_OK\n"}
    ]
    with patch("colab_cli.commands.diagnostics.ColabRuntime", return_value=runtime):
        result = runner.invoke(app, ["test", "kernel", "-s", "demo"])

    assert result.exit_code == 0, result.output
    assert "[PASS] kernel" in result.output
    runtime.stop.assert_called_once()
