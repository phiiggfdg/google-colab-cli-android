import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
RUNNER = ROOT / "integration" / "_runner.sh"

def _bash(script: str, **env_overrides: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env.update(env_overrides)
    return subprocess.run(["bash", "-c", f'source "{RUNNER}"; {script}'], cwd=ROOT, env=env, text=True, capture_output=True, check=False)

def test_termux_auto_uses_current_source_python():
    result = _bash("colab_command version", TERMUX_VERSION="test", COLAB_TEST_RUNNER="auto", PYTHON_BIN="/usr/bin/python3")
    assert result.returncode == 0, result.stderr
    assert "python3" in result.stdout
    assert "-m colab_cli.cli" in result.stdout
    assert "uv run colab" not in result.stdout
    assert f"PYTHONPATH={ROOT / 'src'}" in result.stdout

def test_uv_mode_preserves_upstream_dev_runner():
    result = _bash("colab_command version", COLAB_TEST_RUNNER="uv")
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "uv run colab version"

def test_installed_mode_can_be_selected_explicitly():
    result = _bash("colab_command --help", COLAB_TEST_RUNNER="installed", COLAB_BIN="/tmp/custom-colab")
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == "/tmp/custom-colab --help"

def test_invalid_runner_mode_fails_loudly():
    result = _bash("colab_command version", COLAB_TEST_RUNNER="mystery")
    assert result.returncode == 2
    assert "invalid COLAB_TEST_RUNNER" in result.stderr
