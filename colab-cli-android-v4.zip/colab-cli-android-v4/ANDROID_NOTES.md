# Colab CLI Android/Termux compatibility build

This tree is based on the latest upstream `google-colab-cli` source included in
this package. The Android port keeps upstream command behavior and replaces only
native dependency paths that are known to be problematic on Termux.

## Install

From the extracted source directory:

```bash
pip install . --break-system-packages
```

Python 3.12 or newer is required.

## Why compatibility modules exist

The upstream package currently pulls dependency chains that are difficult to
install on Android/Termux ARM64:

- `nbformat -> jsonschema -> referencing -> rpds-py`
- `pydantic -> pydantic-core`
- newer `google-auth -> cryptography`
- `jupyter-kernel-client` and its transitive stack

This build avoids replacing broad application logic. Instead it uses focused,
pure-Python compatibility layers:

- `colab_cli.ipynb_lite` for the nbformat-v4 operations used by the CLI
- `colab_cli.pydantic_lite` for the model/alias/coercion operations used by the CLI
- `colab_cli.ws_kernel` for the Jupyter JSON WebSocket kernel transport
- `google-auth>=2.47,<2.48` to retain the authentication API used by this CLI
  without forcing the newer native cryptography dependency chain

The upstream `uv.lock` file is intentionally omitted because it describes the
official dependency graph, including packages removed by this Android port.
`pip install . --break-system-packages` is the supported installation path for
this source package.

## Diagnostics

Run all local, non-network compatibility checks:

```bash
colab test
```

Run one layer at a time:

```bash
colab test environment
colab test notebook
colab test models
colab test kernel-codec
```

After creating a real Colab session, test the live kernel transport separately:

```bash
colab new -s android-test
colab test kernel -s android-test
```

The live kernel test executes only a small `print()` statement. It is not run by
`colab test` automatically, so diagnostics never allocate or touch a remote
runtime unless the user explicitly requests it.

## Updating

On Termux, `colab update --install` is intentionally disabled. Installing the
official PyPI build over this port can restore native dependencies that fail on
Android. `colab update` may still report newer upstream versions for reference;
rebase Android compatibility changes onto the newer upstream source instead of
blindly replacing the package.
